
package estacionamiento;
import java.util.Scanner;

public class Estacionamiento {
    public static void main(String[] args) {
      
        Scanner entrada=new Scanner (System.in);
        System.out.println("Ingrese la hora de entrada:");

        int HE=entrada.nextInt();
        
                System.out.println("Ingrese la hora de salida:");

        int HS=entrada.nextInt();
        int sum=HE*HS;
        System.out.print("");
        
        int pago=0;
        int horadeestadia=HS-HE;
        int fraccion=horadeestadia;
        int horarestante=horadeestadia-1;
        
        
        if (horadeestadia>1){
            pago=1000+(horarestante*600);
        }else{
            pago=1000;
        }
        System.out.println("El total a pagar es: " + pago);
        
    } }
